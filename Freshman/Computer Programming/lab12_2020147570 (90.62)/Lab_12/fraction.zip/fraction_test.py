from fraction import Fraction
# Imports class Fraction from module fraction.py

f1 = Fraction(2, 12)
f2 = Fraction(1, 6)
f2.num = 2
print('f1:', f1)
print('f2:', f2)
